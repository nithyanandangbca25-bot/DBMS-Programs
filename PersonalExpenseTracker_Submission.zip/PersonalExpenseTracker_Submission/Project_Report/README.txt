PERSONAL EXPENSE TRACKER
README / SETUP INSTRUCTIONS

Student: Nithyanandan G
Project: Personal Expense Tracker
Technology: Java Swing, JDBC, MySQL
Database name: expense_tracker
Table name: expenses

1. PROJECT OVERVIEW
This is a Java desktop application for managing personal expenses. It allows users to add expenses, view/refresh saved records, update selected records, and delete selected records. Expense data is stored in a MySQL database.

2. SOFTWARE REQUIRED
- Java JDK
- Apache NetBeans IDE
- MySQL Server
- MySQL Connector/J (JDBC driver)
- MySQL Workbench (optional, for viewing and checking database records)

3. DATABASE SETUP
1. Start the MySQL Server.
2. Open MySQL Workbench and connect to your local MySQL server.
3. Open the file Database_SQL/expense_tracker.sql.
4. Execute the SQL script to create the expense_tracker database and expenses table.
5. To check saved records, run:
   USE expense_tracker;
   SELECT * FROM expenses;

Note: The SELECT query may show zero rows until expenses are added through the application.

4. JDBC CONFIGURATION
The application connects to the local MySQL server using this JDBC URL:
jdbc:mysql://localhost:3306/expense_tracker

The Java connection settings use:
- Username: root (or your own MySQL username)
- Password: your local MySQL password

IMPORTANT: Do not share your real database password in this README, screenshots, source code submitted publicly, or GitHub. If the source code contains a password, replace it with a placeholder before sharing and configure your own password locally.

5. MYSQL CONNECTOR/J
The project requires the MySQL Connector/J JAR to be available on the project's classpath.
If NetBeans cannot find the JDBC driver:
1. Right-click the project in NetBeans and select Properties.
2. Open Libraries.
3. Add the MySQL Connector/J JAR file.
4. Clean and Build the project, then run it again.

For portability, include a copy of the Connector/J JAR in the submission only if permitted by your instructor and the connector's licence; otherwise provide the official driver separately and add it to the classpath on the target computer.

6. RUN THE APPLICATION
1. Open NetBeans.
2. Choose File > Open Project.
3. Select the PersonalExpenseTracker folder inside Application_Code.
4. Confirm the MySQL server is running and the database/table have been created.
5. Verify the JDBC URL, username and local password in the Java connection settings.
6. Run the project using Run Project (F6).

7. USING THE APPLICATION
- Add Expense: enter the date, category, amount and description, then click Add Expense.
- View / Refresh: click Refresh to reload saved records from MySQL.
- Update Selected: select a row, edit the populated fields, then click Update Selected.
- Delete Selected: select a row and click Delete Selected; confirm if prompted.
- Clear Fields: click Clear Fields to clear the form inputs.

8. TROUBLESHOOTING
- “No suitable driver found”: make sure MySQL Connector/J is added to the NetBeans project's Libraries/classpath.
- Connection refused / communications link failure: make sure MySQL Server is running and the JDBC URL/port are correct.
- Access denied for user: check the MySQL username and local password.
- Unknown database or table: execute Database_SQL/expense_tracker.sql in MySQL Workbench.
- No records shown: add an expense in the application, refresh, then run SELECT * FROM expenses; in Workbench.

9. SCREENSHOTS AND REPORT
The Screenshots folder should contain actual screenshots of:
- The running application
- The MySQL table structure
- Expense records saved through the application
- An updated expense record

The Project_Report folder contains the project report PDF. Replace all screenshot placeholders in the report with the actual screenshots before submitting.

END OF README
