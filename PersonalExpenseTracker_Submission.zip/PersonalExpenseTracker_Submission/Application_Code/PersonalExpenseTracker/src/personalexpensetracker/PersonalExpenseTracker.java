
package personalexpensetracker;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.math.BigDecimal;

public class PersonalExpenseTracker extends JFrame {

    private JTextField dateField;
    private JTextField categoryField;
    private JTextField amountField;
    private JTextField descriptionField;

    private JTable table;
    private DefaultTableModel model;

    private final String URL =
            "jdbc:mysql://localhost:3306/expense_tracker";
    private final String USER = "root";

   
    private final String PASSWORD = "mysql2026";

    public PersonalExpenseTracker() {

        setTitle("Personal Expense Tracker");
        setSize(900, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        JLabel heading = new JLabel(
                "PERSONAL EXPENSE TRACKER",
                SwingConstants.CENTER);
        heading.setFont(new Font("Arial", Font.BOLD, 22));
        add(heading, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridLayout(2, 4, 8, 8));
        form.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        dateField = new JTextField("2026-10-26");
        categoryField = new JTextField();
        amountField = new JTextField();
        descriptionField = new JTextField();

        form.add(new JLabel("Date (YYYY-MM-DD):"));
        form.add(new JLabel("Category:"));
        form.add(new JLabel("Amount:"));
        form.add(new JLabel("Description:"));

        form.add(dateField);
        form.add(categoryField);
        form.add(amountField);
        form.add(descriptionField);

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.add(heading, BorderLayout.NORTH);
        topPanel.add(form, BorderLayout.CENTER);

        add(topPanel, BorderLayout.NORTH);
        remove(heading);

        model = new DefaultTableModel(
                new String[]{
                    "ID", "Date", "Category", "Amount", "Description"
                }, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(model);
        table.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION);

        add(new JScrollPane(table), BorderLayout.CENTER);

        JButton addButton = new JButton("Add Expense");
        JButton refreshButton = new JButton("Refresh");
        JButton updateButton = new JButton("Update Selected");
        JButton deleteButton = new JButton("Delete Selected");
        JButton clearButton = new JButton("Clear Fields");

        JPanel buttons = new JPanel(new FlowLayout());
        buttons.add(addButton);
        buttons.add(refreshButton);
        buttons.add(updateButton);
        buttons.add(deleteButton);
        buttons.add(clearButton);

        add(buttons, BorderLayout.SOUTH);

        addButton.addActionListener(e -> addExpense());
        refreshButton.addActionListener(e -> loadExpenses());
        updateButton.addActionListener(e -> updateExpense());
        deleteButton.addActionListener(e -> deleteExpense());
        clearButton.addActionListener(e -> clearFields());

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                fillFieldsFromSelectedRow();
            }
        });

        loadExpenses();
    }

    private Connection connect() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    private boolean validateFields() {
        if (dateField.getText().trim().isEmpty()
                || categoryField.getText().trim().isEmpty()
                || amountField.getText().trim().isEmpty()) {

            JOptionPane.showMessageDialog(this,
                    "Please enter date, category and amount.");
            return false;
        }

        try {
            Date.valueOf(dateField.getText().trim());

            BigDecimal amount = new BigDecimal(
                    amountField.getText().trim());

            if (amount.compareTo(BigDecimal.ZERO) <= 0) {
                JOptionPane.showMessageDialog(this,
                        "Amount must be greater than zero.");
                return false;
            }

        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this,
                    "Enter a valid date (YYYY-MM-DD) and amount.");
            return false;
        }

        return true;
    }

    private void addExpense() {
        if (!validateFields()) {
            return;
        }

        String sql = "INSERT INTO expenses "
                + "(expense_date, category, amount, description) "
                + "VALUES (?, ?, ?, ?)";

        try (Connection con = connect();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setDate(1, Date.valueOf(dateField.getText().trim()));
            ps.setString(2, categoryField.getText().trim());
            ps.setBigDecimal(3,
                    new BigDecimal(amountField.getText().trim()));
            ps.setString(4, descriptionField.getText().trim());

            ps.executeUpdate();

            JOptionPane.showMessageDialog(this,
                    "Expense added successfully!");

            loadExpenses();
            clearFields();

        } catch (SQLException ex) {
            showDatabaseError(ex);
        }
    }

    private void loadExpenses() {
        model.setRowCount(0);

        String sql = "SELECT * FROM expenses "
                + "ORDER BY expense_date DESC, id DESC";

        try (Connection con = connect();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getDate("expense_date"),
                    rs.getString("category"),
                    rs.getBigDecimal("amount"),
                    rs.getString("description")
                });
            }

        } catch (SQLException ex) {
            showDatabaseError(ex);
        }
    }

    private void fillFieldsFromSelectedRow() {
        int selected = table.getSelectedRow();

        if (selected == -1) {
            return;
        }

        dateField.setText(
                model.getValueAt(selected, 1).toString());
        categoryField.setText(
                model.getValueAt(selected, 2).toString());
        amountField.setText(
                model.getValueAt(selected, 3).toString());

        Object description = model.getValueAt(selected, 4);
        descriptionField.setText(
                description == null ? "" : description.toString());
    }

    private void updateExpense() {
        int selected = table.getSelectedRow();

        if (selected == -1) {
            JOptionPane.showMessageDialog(this,
                    "Select an expense row to update.");
            return;
        }

        if (!validateFields()) {
            return;
        }

        int id = (int) model.getValueAt(selected, 0);

        String sql = "UPDATE expenses SET expense_date=?, "
                + "category=?, amount=?, description=? WHERE id=?";

        try (Connection con = connect();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setDate(1, Date.valueOf(dateField.getText().trim()));
            ps.setString(2, categoryField.getText().trim());
            ps.setBigDecimal(3,
                    new BigDecimal(amountField.getText().trim()));
            ps.setString(4, descriptionField.getText().trim());
            ps.setInt(5, id);

            int rows = ps.executeUpdate();

            if (rows > 0) {
                JOptionPane.showMessageDialog(this,
                        "Expense updated successfully!");
                loadExpenses();
                clearFields();
            }

        } catch (SQLException ex) {
            showDatabaseError(ex);
        }
    }

    private void deleteExpense() {
        int selected = table.getSelectedRow();

        if (selected == -1) {
            JOptionPane.showMessageDialog(this,
                    "Select an expense row to delete.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to delete this expense?",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION);

        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        int id = (int) model.getValueAt(selected, 0);

        String sql = "DELETE FROM expenses WHERE id=?";

        try (Connection con = connect();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();

            JOptionPane.showMessageDialog(this,
                    "Expense deleted successfully!");

            loadExpenses();
            clearFields();

        } catch (SQLException ex) {
            showDatabaseError(ex);
        }
    }

    private void clearFields() {
        table.clearSelection();
        dateField.setText("2026-10-26");
        categoryField.setText("");
        amountField.setText("");
        descriptionField.setText("");
    }

    private void showDatabaseError(SQLException ex) {
        JOptionPane.showMessageDialog(this,
                "Database error: " + ex.getMessage());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new PersonalExpenseTracker().setVisible(true);
        });
    }
}
